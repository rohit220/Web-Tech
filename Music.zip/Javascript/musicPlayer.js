var image=document.querySelector("img")
var audio=document.querySelector("audio")
var name=document.querySelector("na")
var previousBtn=document.querySelector(".fa-backword")
var pauseBtn=document.querySelector(".fa-pause")
var playBtn=document.querySelector(".fa-play")
var nextBtn=document.querySelector(".fa-forward")
var shuffleBtn=document.querySelector(".fa-shuffle")
var voumeBtn=document.querySelector("#volume")

var storage=[
             {audioSource: "./media/m1.mp3",imageSource:"./media/a1.jpg"},
             {audioSource: "./media/m1.mp3",imageSource:"./media/a1.jpg"},
             {audioSource: "./media/m1.mp3",imageSource:"./media/a1.jpg"},
             {audioSource: "./media/m1.mp3",imageSource:"./media/a1.jpg"}]

 var index=0
function playfun() {
    image.src=storage[index].imageSource
    audio.src=storage[index].audioSource
    audio.play()
    playBtn.style.display="none"
}
playfun()




