var h1=document.getElementById("msd")
var btn=document.getElementById("btn")
console.log(h1,btn);

var pa=document.getElementById("para")
var li=document.getElementById("list")

var h2=document.getElementById("virat")
var btn2=document.getElementById("btn2")

// pa.innerHTML="India is the best cricket team ever"//change in js file 
// h2.innerText="VIRAT KOHLI" //changing runtime

console.log(pa,li);
console.log(virat,btn2);

function bantai(){
    h1.innerText="DHONI Bolte.........."
}
// bantai()

function vir(){
    h2.innerHTML="Virat bhai....."
}

function par(){
    pa.innerText="India is the best cricket team ever"
}

var image=document.getElementById("img1")
function img(){
 
    image.src="./images/rohit1.jpg"
}


var img=document.getElementById("img2")

function img2(){
    img.src="./images/d2.jpg"
}