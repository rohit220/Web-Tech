var firstrandom=Math.random()*70
var firstwhole=Math.floor(firstrandom)

console.log(firstrandom);
console.log(firstwhole);


var secondrandom=Math.random()*50
var secondwhole=Math.floor(secondrandom)

console.log(secondrandom);
console.log(secondwhole);
//

var ran=0
function rn(ran){
    return Math.floor(Math.random()*ran)
}

var fr=rn(20)
console.log(`fr :${fr}`);


var hh1 = document.getElementById("r1")
// console.log(hh1);

function rand(){
    var firran = Math.floor(Math.random()*10)
    console.log(firran);

}

rand()
rand()
rand()


