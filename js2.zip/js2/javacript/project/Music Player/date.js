var h1=document.querySelector("h1")
var d=document.querySelector("#date")


function time(){
    var date=new Date()
    var hours=date.getHours()
    var min=date.getMinutes()
    var sec=date.getSeconds()

    if(hours<10){
        hours="0"+hours
    }
    if(min<10){
        min="0"+min
    }
    if(sec<10){
        sec="0"+sec
    }


    h1.innerHTML=`${hours}::${min}::${sec}`

}
setInterval(time,1000)


function date(){
    var date=new Date()
    var dd=date.getDay()
    var mm=date.getMonth()
    var yy=date.getUTCFullYear()
    
    d.innerHTML=`${dd+3}\\${mm+1}\\${yy}`
}
date()