var image=document.querySelector("img")
var audio=document.querySelector("audio")
var name=document.querySelector("na")
var previousBtn=document.querySelector(".fa-backward")
var pauseBtn=document.querySelector(".fa-pause")
var playBtn=document.querySelector(".fa-play")
var nextBtn=document.querySelector(".fa-forward")
var shuffleBtn=document.querySelector(".fa-shuffle")
var volumeBtn=document.querySelector("#volume")
var audiorange=document.querySelector("#audiorange")

var storage=[
             {audioSource: "./media/m1.mp3",imageSource:"./media/a1.jpg"},
             {audioSource: "./media/m2.mp3",imageSource:"./media/a2.jpg"},
             {audioSource: "./media/m3.mp3",imageSource:"./media/a3.jpg"},
             {audioSource: "./media/m4.mp3",imageSource:"./media/a4.jpg"}]

 var index=0
 var realTime=0
 pauseBtn.style.display="none"


function playfun() {
    image.src=storage[index].imageSource
    audio.src=storage[index].audioSource
    audio.currentTime=realTime
    image.style.display="block"

    audio.play()

    setInterval(()=>{
        audiorange.value=(audio.currentTime/audio.duration)*100
    },1000)
    playBtn.style.display="none"
    pauseBtn.style.display="flex"
    audiorange.style.display="block"

}

function pausePlay(){
    if(audio.paused){
        playfun()
    }
    else{
        audio.pause()
        realTime=audio.currentTime
        playBtn.style.display="flex"
        pauseBtn.style.display="none"
    }
}

playBtn.addEventListener("click",pausePlay)
pauseBtn.addEventListener("click",pausePlay)


nextBtn.addEventListener("click",function () {
    index=(index+1)%storage.length
    realTime=0
    playfun()
})

previousBtn.addEventListener("click", ()=>{
    index=(index-1+storage.length)%storage.length
    realTime=0
    playfun()
})

volumeBtn.addEventListener("input",()=>{
    audio.volume=volumeBtn.value
})

audiorange.addEventListener("input",()=>{
    audio.currentTime=(audiorange.value*audio.duration)/100
})

audio.addEventListener("ended",()=>{
    index=(index+1)%storage.length
    realTime=0
    playfun()
})

