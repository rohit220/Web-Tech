
console.log(localStorage.getItem("array"));

var jarray=JSON.parse(localStorage.getItem("array"))
// console.log(jarray);

var list=["Abc","bbb","ccc","ddd","eee","fff"]

list.forEach((e)=>{
    // console.log(e);
})

var copystorage=list.map((e)=>{
    console.log(e);
    return e
})
var copystorage2=list.forEach((e)=>{
    console.log(e);
    return e
})


console.log(copystorage);
console.log(copystorage2);


var num=[1,2,3,4,5]
console.log(num);


var copynum = num.map((e)=>{
    console.log(e);
    return e*20
})

var copynum2 = num.forEach((e)=>{
    console.log(e);
    return e
})

console.log(copynum);
console.log(copynum2);

var btn=document.querySelectorAll("button")

// console.log(btn);
// btn.forEach((e)=>{
//     console.log(e);
// })

btn.forEach((e)=>{
    e.addEventListener("click",()=>{
        // console.log(e);
    })
})

var h1=document.querySelectorAll("h1")
console.log(h1);
h1.forEach((e)=>{
    // console.log(e);
})

var btns=document.querySelectorAll(".clr")
var body=document.querySelector("body")

btns.forEach((e)=>{
    e.addEventListener("click",()=>{
        body.style.backgroundColor=e.innerHTML
    })
})
// ------------------------------------------

var size = document.querySelectorAll(".size")
var p= document.querySelector("p")

size.forEach((e)=>{
    e.addEventListener("click",()=>{
        p.style.fontSize=e.innerHTML
    })
})