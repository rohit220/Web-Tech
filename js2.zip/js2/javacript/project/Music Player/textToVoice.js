var text=document.querySelector("textarea")
var btn=document.querySelector("button")
var select=document.querySelector("select")
// var body=document.querySelector("body")

// function demo(){
//     var dummny=["none","red","black","yellow","orange","purple"]

//     dummny.forEach((e)=>{
//         var opt=document.createElement("option")
//         opt.innerHTML=e
//         select.appendChild(opt)
//     })

//     select.addEventListener("click",()=>{
//         body.style.backgroundColor=select.value
//     })


// }
// demo()

function dropdown(){

    var mulVoice= speechSynthesis.getVoices()
    mulVoice.map((e)=>{
        var opt=document.createElement("option")
        opt.innerHTML=e.name
        select.appendChild(opt)

    })


}

speechSynthesis.addEventListener("voiceschanged",dropdown)


function voice(){

    var audio=new SpeechSynthesisUtterance(text.value)
    var mulVoice=speechSynthesis.getVoices()
    console.log(mulVoice);

    var zira=mulVoice.find((e)=>{
        if(e.name==select.value){
            return e
        }
    })

    console.log(zira);
    audio.voice=zira
    speechSynthesis.speak(audio)
}

btn.addEventListener("click",voice)