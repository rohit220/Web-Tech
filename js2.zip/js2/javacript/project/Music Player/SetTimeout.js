// setTimeout(()=>{
//     console.log("I will display after 5 sec");
// },5000)

// setTimeout(function(){
//     console.log("I will display after 2 sec");
// },2000)

// function Test(){
//     console.log("i Am function....");
// }

// setTimeout(Test,4000)

// setInterval(()=>{
//     console.log("I will execute after evry 5 seconds");
// },5000)

// var count=0

// var interval=setInterval(()=>{
//     count+=1
//     console.log(count);
// },1000)

// clearInterval(interval)


var set=document.querySelector("#set")
var clear=document.querySelector("#clear")
// console.log(set,clear);

var count=0
var interval=null

set.addEventListener("click",()=>{
    interval=setInterval(()=>{
        count+=1
        console.log(count);
    },1000)
})

clear.addEventListener("click",()=>{
    clearInterval(interval)
})