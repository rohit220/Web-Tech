// localStorage.setItem("a","Rohit")
// localStorage.setItem("place","Thane")
// localStorage.setItem("Company","ISG")
// localStorage.setItem("Age","24")
// localStorage.setItem("No","123456789")


// console.log(localStorage.getItem("a"));
// console.log(localStorage.getItem("place"));
// console.log(localStorage.getItem("Company"));
// console.log(localStorage.getItem("Age"));
// console.log(localStorage.getItem("No"));


// localStorage.removeItem("No")

// localStorage.clear()

var a="Rohit"
var email="rohit@gmail.com"
var no=123456789

var num=["one","two","three","four","five"]

var emp={
    name:"Rohit",
    num:123,
    loc:"thane"
}
// // localStorage.setItem("name",a)
// // localStorage.setItem("email",email)
// localStorage.setItem("number",no)

localStorage.setItem("array",JSON.stringify(num)) // convert value into JSON format
localStorage.setItem("jobject",JSON.stringify(emp))




console.log(localStorage.getItem("name"));
console.log(localStorage.getItem("email"));
console.log(localStorage.getItem("number"));




