var login=JSON.parse(localStorage.getItem("login"))
var username=document.querySelector("#username")
var right=document.querySelector("#right")
var male=document.querySelector("#male")

if(login){
    username.innerHTML=login.fname
    var btn=document.createElement("button")
    btn.innerHTML="logout"
    right.appendChild(btn)
    btn.addEventListener("click",()=>{
        localStorage.removeItem("login")
    })
}

async function displayproduct(){

    try{
        var api= await fetch("https://www.shoppersstack.com/shopping/products/alpha")
    console.log(api);
    var apiJson=await api.json()
    console.log(apiJson)
    var data =apiJson.data
    console.log(data)

    var maledata=data.filter((e)=>{
        if(e.category=="men"){
            return e
        }
    })

    console.log(maledata);


    maledata.map((e)=>{
        male.innerHTML +=`<div class="cont" id="p${e.productId}">
        <img src="${e.productImageURLs[0]}" alt="">
        <h3>${e.name}</h3>
        <p>${e.description}</p>
        <div>
            <h4>Price : ${e.price}</h4>
            <h5>Rating : ${e.rating}</h5>
        </div>
        <button>Add To Cart</button>
    </div>`
    })


    }
    catch(error){
        console.log(error);
    }

}
displayproduct()