var input=document.querySelectorAll("input")
var span=document.querySelectorAll("span")
var form=document.querySelector("form")
var storage=[]
var lstorage=JSON.parse(localStorage.getItem("lstorage"))
if(lstorage){
    storage=lstorage
}

// console.log(input,span,form);

form.addEventListener("submit",(e)=>{
    var flag=true

    span[2].innerHTML=""
    var reqx=/^[a-zA-Z]{2,10}$/
    var regx1=/^[6-9][0-9]{9}$/
    // var regx2=/^[a-zA-Z0-9!]{8,15}$/
    var reqx2=/^[a-zA-Z]{2,10}$/

    if(input[0].value==""){
        span[0].innerHTML="First Name Required"
        flag=false
        e.preventDefault()

    }
    else if(reqx.test(input[0].value)){
        span[0].innerHTML=""
        e.preventDefault()
    }
    else {
        span[0].innerHTML="Invalid First Name"
        flag=false
        e.preventDefault()

    }



    if(input[1].value==""){
        span[1].innerHTML="Last Name is Required"
        flag=false
        e.preventDefault()

    }
    else if(reqx.test(input[1].value)){
        span[1].innerHTML=""
        e.preventDefault()
    }
    else {
        span[1].innerHTML="Invalid Last Name"
        flag=false
        e.preventDefault()

    }



    if(input[2].value==""){
        span[2].innerHTML="Email is Required"
        flag=false
        e.preventDefault()

    }




    if(input[3].value==""){
        span[3].innerHTML="Mobile Number is Required"
        flag=false
        e.preventDefault()

    }
    else if(regx1.test(input[3].value)){
        span[3].innerHTML=""
        e.preventDefault()
    }
    else{
        span[3].innerHTML="Invalid Mobile no"
        flag=false
        e.preventDefault()

    }




    if(input[4].value==""){
        span[4].innerHTML="Password is Required"
        flag=false
        e.preventDefault()
    }
    else if(reqx2.test(input[4].value)){
        span[4].innerHTML=""
        e.preventDefault()

    }
    else{
        span[4].innerHTML="Invalid Password"
        flag=false
        e.preventDefault()
    }



    if(input[5].value==""){
        span[5].innerHTML=" Confirm Password is Required"
        flag=false
        e.preventDefault()
        
    }
    else if(input[5].value==input[4].value){
        span[5].innerHTML=""
        e.preventDefault()
    }
    else{
        span[5].innerHTML="Password and Confirm password is not matching"
        flag=false
    }




    if(flag){
    var obj={
        fname:input[0].value,
        lname:input[1].value,
        email:input[2].value,
        number:input[3].value,
        pass:input[4].value,
        confpass:input[5].value    
    }
    storage.push(obj)

    localStorage.setItem("lstorage",JSON.stringify(storage))
    }
    


})