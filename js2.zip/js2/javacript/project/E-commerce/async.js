
// setTimeout(()=>{
//     console.log(" 2 seconds");
//     setTimeout(()=>{
//         console.log("3 Seconds");

//         setTimeout(()=>{
//             console.log(" 0 sec");
//         },0)
//     },1000)


//     setTimeout(()=>{
//         console.log(" 2 seconds");
//     },0)
// },2000)


// var propose=new Promise((resolve,reject)=>{
    
//     var dec=Math.floor(Math.random()*2)
//     if(dec==1){
//         resolve()
//     }
//     else{
//         reject()
//     }
// })

// console.log(propose);

// propose
// .then(()=>{
//     console.log("Accepted");
// })
// .catch(()=>{
//     console.log("Rejected");
// })
 

// var storage = fetch("./data.json")
// console.log(storage);

// storage
// .then((res)=>{
//     var response=res.json()
//     console.log(response);
//     response.
//     then((data)=>{
//         console.log(data.storage[0].name);
//     })
//     .catch((error)=>{
//         console.log(error);
//     })
// })

// .catch((error)=>{
//     console.log(error);
// })

// var shoppers=fetch("https://www.shoppersstack.com/shopping/products/alpha")

// console.log(shoppers);

// shoppers
// .then((res)=>{
//     var response=res.json()
//     console.log(response);
//     response
//     .then((e)=>{
//         console.log(e.data[0].name);
//     })
// })
// .catch((error)=>{
//     console.log(error);

// })

var body=document.querySelector("body")

async function handlepromise(){

   try{
    var api= await fetch("https://www.shoppersstack.com/shopping/products/alpha")
    console.log(api);
    var apiJson=await api.json()
    console.log(apiJson);
    console.log(apiJson.data);

    apiJson.data.forEach((e)=>{
        var h2=document.createElement("h2")
        h2.innerHTML=e.name
        body.appendChild(h2)

    })
   }
   catch(error){
    console.log("some Error in code");
   }

}



handlepromise()