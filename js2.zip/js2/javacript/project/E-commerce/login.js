var input=document.querySelectorAll("input")
var btn=document.querySelectorAll("button")[0]
var form=document.querySelector("form")
var span=document.querySelectorAll("span")
var lstorage=JSON.parse(localStorage.getItem("istorage"))
console.log(lstorage);

form.addEventListener("submit",(e)=>{
    var flag=true

    // span[0].innerHTML=""
    // span[1].innerHTML=""
    // span[2].innerHTML=""


        span.forEach((e)=>{
            e.innerHTML=""
        })
  
        var matching=lstorage.find((e)=>{
            if(input[0].value==e.mobile && input[1].value==e.pass){
                return e
            }
        })


    if(input[0].value=="" && input[1].value==""){
        span[0].innerHTML="Username is Required"
        span[1].innerHTML="Password is Required"
        e.preventDefault()
        flag=false
    }
    else if(input[0].value=="" ){
        span[0].innerHTML="Please Enter UserName"
        e.preventDefault()
        flag=false

    }
    else if(input[1].value==""){
        span[1].innerHTML="Please Enter Paasword"
        e.preventDefault()
        flag=false

    }
    else if(matching){

        alert("Welcome")
    }
    else{
        span[2].innerHTML="Username & Password not matching"
        e.preventDefault()
        flag=false
    }

    if(flag){
        localStorage.setItem("login",JSON.stringify(matching))

    }
})
