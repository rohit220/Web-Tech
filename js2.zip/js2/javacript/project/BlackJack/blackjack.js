var pcards=document.getElementById("pcards")
var ptotal=document.getElementById("ptotal")
var ctotal=document.getElementById("ctotal")
var startbtn=document.getElementById("startbtn")
var message=document.getElementById("message")
var buts=document.getElementById("but")
// console.log(pcards,ptotal,ctotal,startbtn,but,message);
var storage=[]
var computerStorage=[]
var playerSum=0
var comsum=0
var game=true
var player="rohit"
var stake=2000 

// Start Game

function start(){

    // startbtn.style.display=`none`;
    buts.style.display=`flex`;  
    storage=[]
    // computerStorage=[]
    playerSum=0
    // comsum=0




//Player
    var playerCardOne=ra()
    var playerCardTwo=ra()
//computer
    
    var playerCardOne=ra()
    var playerCardTwo=ra()

    storage.push(playerCardOne)
    storage.push(playerCardTwo)
    computerStorage.push(playerCardOne)
    computerStorage.push(playerCardTwo)
    
    comsum=playerCardOne+playerCardTwo

    playerSum=playerCardOne+playerCardTwo

    // for (var i=0;i<storage.length;i++){
       
    //     playerSum=playerSum+storage[i]
    // }

    // console.log(storage);
    // console.log(playerSum);
    
    print()
    
}





function print(){
    pcards.innerHTML=`Player Cards : `
    for(i=0;i<storage.length;i++){
        pcards.innerHTML+=`-${storage[i]} `
    }

    ptotal.innerHTML =`Player Total : ${playerSum}`
    ctotal.innerHTML=`Computer Total :${comsum}`



    if(playerSum==21){
        message.innerHTML=`congrats ${player} you won Rs.${stake*2} the game`
        message.style.color=`green`
    }
    else if(playerSum>21){
        message.innerHTML=`Sorry ${player} you Lost Rs.${stake} the game`
        message.style.color=`red`
        

    }
    else {
        message.innerHTML=`Do You want new Card?`
        message.style.color=`white`
    }
    
}

function ra(){

    var number = Math.floor(Math.random()*13+1)

    if(number==1){
        return 11
    }
    else if(number>10){
        return 10
    }

    else{
        return number
    }
}

function newcard(){
    if(playerSum<21 && game==true){
    var playerCardThree = ra()

    
    storage.push(playerCardThree)
    playerSum += playerCardThree


    print()
    }

    if(playerSum==21){
    computerNewCard()
    }
}




function computerNewCard(){
    
    while(comsum<17){
    var computerCardThree=ra()
    computerStorage.push(computerCardThree)
    comsum += computerCardThree
    ctotal.innerHTML=`Computer Total :${comsum}`

    console.log(comsum);
    }

    
    if((playerSum>comsum && playerSum<= 21) || (playerSum<comsum && comsum>21)){
        message.innerHTML=`congrats ${player} you won Rs.${stake} the game`
        message.style.color=`green`
        
    }
    else if((comsum>playerSum && comsum<=21) || (comsum<playerSum && playerSum>21)){

        message.innerHTML=`Sorry ${player} you Lost Rs.${stake} the game`
        message.style.color=`red`
    }

    else{
        message.innerHTML=`Draw The Game`
        message.style.color=`orange`
    }
   
    game=false
}