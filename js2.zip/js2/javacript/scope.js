// function dummy(){

//     var a=100
//     let b=200
//     const c =300
// }
// dummy()
// console.log(a);//not defined
// console.log(b);//not defined
// console.log(c);//not defined
//---------------------------------------------------
// if(true){

//     var a=100
//     let b=200
//     const c =300
// }

// console.log(a);
// console.log(b);// not defined -block scope
// console.log(c);// not defined -block scope
//---------------------------------------------------
// var a =20
// let b=40
// const c=70

// if(true){
//     console.log(a);
//     console.log(b);
//     console.log(c);
// }

//---------------------------------------------------

// var a =201
// let b=401
// const c=701

// function dummy(){
//     console.log(a);
//     console.log(b);
//     console.log(c);
// }

// dummy()


//------------------------------------------------------------



// function outer(){

//     var a =201
//     let b=401
//     const c=701
    
//     if(true){
//         console.log(a);
//         console.log(b);
//         console.log(c);
//     }
// }

// outer()

//--------------------------------------------------------------------

// function outer(){
    
//     if(true){
      
//     var a =201
//     let b=401
//     const c=701 
//         }

//    console.log(a);
//    console.log(b);
//    console.log(c);
// }

// outer()

//----------------------------------------------------------
// function inner(){

//     var a =201
//     let b=401
//     const c=701
// }
//     inner()

//    console.log(a);//Not defined
//    console.log(b);//Not defined
//    console.log(c);//Not defined


var a=50
var b=70

function add(){
    result()
}

add()

function result(){
    console.log(a+b);
}


function sub(){
    resultsub()
}

sub()

function resultsub(){
    console.log(a-b);
}

function mul(){
    resultmul()
}

mul()

function resultmul(){
    console.log(a*b);
}