var array=['rohit','virat','msd','pandya','bumrah']

array.splice(2,1,'kohli')
console.log(array);


var ipl=['MI','CSK','RR','GT','RCB',]

ipl.splice(4,1)
console.log(ipl);

ipl.splice(4,1,'SRH')
console.log(ipl);

ipl.splice(0,1)
console.log(ipl);

ipl.splice(0,0,'DC')
console.log(ipl);

ipl.splice(2,2,'MI','RCB')
console.log(ipl);


for(var i=ipl.length-1;i>0;i--){
    
    ipl.pop()
    console.log(ipl);
}