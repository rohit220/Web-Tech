var imageStorage=["./images/1.jpg","./images/2.jpg","./images/3.jpg","./images/4.jpg","./images/5.jpg"]
var image=document.getElementById("image")

function memes(){

    var imra=Math.floor(Math.random()*ip.length)
    image.src=imageStorage[imra]
    
}