console.log("JS Bolte...........")
document.write("JS JS JS..........")
alert("okokokokok")
confirm("wanna......")