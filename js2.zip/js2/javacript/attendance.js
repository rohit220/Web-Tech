var attendace = document.getElementById("zero")

var previous = document.getElementById("pr")

var count =0

function score(){
    count +=1
    attendace.innerHTML=count
    

}

function pr(){
    previous.innerHTML +=`${count}-`
    count=0
    attendace.innerHTML=count
}
