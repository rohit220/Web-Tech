var a=4
var b=12.5
var c='c'
var d="e"
var e='ok ok'
var f="Yes Ok..."
var g=true
var h=false

console.log(a)
console.log(b)
console.log(c)
console.log(d)
console.log(e)
console.log(f)
console.log(g)
console.log(h)


var firstNumer=15
var secondNumber=20

console.log(firstNumer,secondNumber);

document.write(a)


let i ="Rohit"
let j='rohit'
let k=12
let l=true

console.log("let values : "+i,j,k,l)

const m="Hello"
const n='Bye'
const o=123
const p=false

console.log("const values :"+m,n,o,p);

// Undefined
var q
console.log(q);

//Null

var x=null
console.log(x);

var z=10
var zz=100
var zzz=1000

a=100
a=150


var numbers=[1,2,3,4,5]

var names=['Rohit','Virat','Pandya']

var city=['Thane','Mumbai','Mulund']

console.log(numbers)
console.log(numbers[1]);

console.log(names);
console.log(names[0]);

console.log(city[0]);
console.log(city)


var actor=['Akshay','Salman','Shahrukh','Shahid','Vidyut']

var actress=['Alia','Deepika','Sunny','Kajol','Kreeti']

var comedy=['Johny','Paresh','Kapil','Rajkumar','Sunil']

var movie=[actor,actress,comedy]

console.log(movie);
console.log(movie[0]);
console.log(movie[1]);
console.log(movie[2]);
console.log(movie[2][1]);
console.log(movie[1][2]);
console.log(movie[0][4]);
console.log(movie[2][0]);

var employee={

    ename: "Rohit",
    designation: "Software_Eng",
    ecode:5429,
    email:"rohit@isg.com",
    contact:123456789,
    dob:"25/03/1999",
    location:"Mumbai",
}

console.log(employee.ename,employee.designation,employee.ecode);
console.log(employee.location);
console.log(employee.city);

var employee2={

    ename: "Rohit",
    designation: "Software_Eng",
    ecode:5429,
    email:"rohit@isg.com",
    contact:123456789,
    dob:"25/03/1999",
    location:{
        loc1:"Mumbai",
        loc2:"Thane",
        loc3:"Kanjurmarg",
    },

    projects:{
        first:"JPMC",
        second:"Yes Bank",
        third:"Kotak",
    }
}

console.log(employee2);
console.log(employee2.projects);
console.log(employee2.projects.first);
console.log(employee2.projects.second);
console.log(employee2.projects.third);

console.log(employee2.location);
console.log(employee2.location.loc2);
console.log(employee2.location.loc1);


var profile={
    userName:{
        name1:"ABC",
        name2:"POI",
        name:"XYZ"
    },
    Email:{
        email1:"abc@g.com",
        email2:"poi@gmail.com",
        email3:"xyz@gmail.com"
    },
    mobile:{
        m1:"Samsung",
        m2:"OPPO",
        m3:"Realme",
        m4:"Xiomi"
    }
}

console.log(profile);
console.log(profile.userName.name1,profile.Email.email1,profile.mobile.m1);
console.log(profile.mobile.m3);
console.log(profile.mobile.m4);
console.log(profile.Email.email3);


var a1=["ABC1","ABC2","ABC3"]
var b1=[100,200,300]
var c1=[a1,b1]

console.log(c1[0][1]);
console.log(c1[0],c1[1]);

var storage=[

    {
        username:"Rohit",
        password:"12345"
    },
    {
        username:"Pravin",
        password:"56789"

    },
    {
        username:"Husain",
        password:"012911"
    }
]

console.log(storage);
console.log(storage[0]);
console.log(storage[2].password);
console.log(storage[1].username);


var movies =[

    {
         name:"Jawan",
         name1:"Leo"

    },
    {
        Actor_name:"Shanrukh",
        Acttress_name:"Deepika",
        Actor_name2:"Vijay"
    },
    {
        type:"Bollywood",
        type2:"south"
        
    }

]

console.log(movies[0].name,movies[1].Actor_name,movies[1].Acttress_name,movies[2].type);
console.log(movies[0].name1,movies[1].Actor_name2,movies[2].type2);


var cloth={
    name:["Shirt","T-Shirt","Pant"],
    price:["1000","2000","1500"],
    size:["M","XL","XXL"]
}

console.log(cloth.name[1],cloth.price[1],cloth.size[1]);

function add(){
    var fn=100
    var sn=250
    var add=fn+sn
    console.log("Addition :"+add);
}
add()

function sub(){
    var fn=23
    var sn=4
    var sub=fn-sn
    console.log("Substraction :"+sub);
}
sub()


function mul(){
    var fn=43
    var sn=22
    var mul=fn*sn
    console.log("Multiplication :"+mul);
}
mul()

function div(){
    var fn=400
    var sn=4
    var div=fn/sn
    console.log("Division :"+div);
}
div()

function mod(){
    var fn=354
    var sn=12
    var mod=fn%sn
    console.log("Modulus :"+mod);
}
mod()

function adds(a,b){
    c=a+b
    console.log("Addition is :"+c);
}

adds(343,726)
adds(635,232)
adds(232,65)

function subs(a,b){
    c=a-b
    console.log("Substraction is :"+c);
}

subs(322,212)


function mult(a,b){
    c=a*b
    console.log("Multiplication is :"+c);
}

mult(11,11)

function divs(a,b){
    c=a/b
    console.log("Division is :"+c);
}

divs(1111,111)

// arrow function =>

var add1=()=>{

    var first=100
    var second=234
    var result = first+second
    console.log("Arrow function addition : "+result);
}

add1()

var sub1=()=>{

    var first=231
    var second=111
    var result = first-second
    console.log("Arrow function substraction : "+result);
}

sub1()

var mul1=()=>{

    var first=21
    var second=21
    var result = first*second
    console.log("Arrow function multiplication : "+result);
}

mul1()

//creating fucntion using Return 

function addd(a,b){
    c=a+b
    return c
}


//Undefined
var store=mod(122,121)
console.log(store);


var addstore = addd(100,120)

console.log("Return Function add :"+addstore);

function subb(a,b){
    c=a-b
    return c
}

var substore = subb(234,120)

console.log("Return Function sub :"+substore);

function mull(a,b){
    c=a*b
    return c
}

var mulstore=mull(212,1)
console.log("Return function mul :"+c);