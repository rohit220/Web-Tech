

var quotes =['You must be the change you wish to see in the world.','Spread love everywhere you go','The only thing we have to fear is fear itself.','Darkness cannot drive out darkness: only light can do that.','Do one thing every day that scares you.','Well done is better than well said.','Spread love everywhere you go','The only thing we have to fear is fear itself.','Darkness cannot drive out darkness: only light can do that.']

var num=document.getElementById("head")
function gen(){

    var ra=Math.floor(Math.random()*quotes.length)

    head.innerHTML=quotes[ra]
}