// var input=document.querySelector("#input")
// var header=document.querySelector("#h1")
// var btn=document.querySelector("#but")


// btn.addEventListener("Click",function(){

//     header.innerHTML=input.value

// })

// function outer(){
//     var a=50
//     function inner(){
//         var b=70
//         console.log(a,b);
//     }
//     inner()
// }

// outer()

// (function(){
//     console.log("I Am...");
// })()

// ()()

// function demo(){
//     console.log("Function...");
//     header.innerHTML="Hellooooo"
// }

// btn.addEventListener("Click",demo)

var fno=document.querySelector("#fno")
var sno=document.querySelector("#sno")
var output=document.querySelector("h1")

var add=document.querySelector("#add")
var sub=document.querySelector("#sub")
var mul=document.querySelector("#mul")
var div=document.querySelector("#div")
var mod=document.querySelector("#mod")


console.log(fno,sno,add,sub,mul,div,mod);


add.addEventListener("click",function add(){

    output.innerHTML= parseInt(fno.value)+parseInt(sno.value)
    
})

sub.addEventListener("click", function(){
    output.innerHTML=fno.value-sno.value
    
})
mul.addEventListener("click", function mul(){
    output.innerHTML=fno.value*sno.value
    
})

function di(){
    output.innerHTML=fno.value/sno.value
}

div.addEventListener("click",di)

