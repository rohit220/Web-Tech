function pos(a){
    if (a>0){
        console.log(`${a} is a positive number`);
    }

    else if(a==0){
        console.log(`${a} is zero`);
    }
    else{
        console.log(`${a} is a negative number`);
    }
    
}

pos(0)




var b=10

if(b>0){
    console.log(`${b} is a positive number`);
}
else{
    console.log(`${b} is a negative number`);
}




function com(c){

    if(c>0){
        console.log(`${c} is a positive number `);
    }

    else if(c<0){
        console.log(`${c} is a negative number`);
    }

    else{
        console.log(`${c} is zero`);
    }

}

com(-10)

var d=2

    if(d%2==0){
        console.log(`${d} is even number`);
    }
    else{
        console.log(`${d} is odd number`);
    }

    
    var number=2001

    if(number%10==0){
        console.log(`${number} is divisible by 10`);
    }
    else{
        console.log(`${number} is not divisible by 10`);
    }

   

    var num=201

    if(num%5==0){
        num=5
    }

    else{
        num=0
    }

    console.log(num);


    var m=100
    var n=10
    var o=20
    nu=0


    if(o%10==0){

        nu=m+n
    }

    else{
        nu=m-n
    }

    console.log(nu);



    

    