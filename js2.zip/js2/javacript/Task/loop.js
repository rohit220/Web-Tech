// for(var i=0 ; i<=10;i++){
//     console.log(i);
// }

// for (var j=10;j>=0;j--){
//     console.log(j);
// }


// var di=document.getElementById(div)

// for(var k=20;k<=50;k++){
//     console.log(k);
//     div.innerHTML += ` ${k} ,`
// }

// var di2=document.getElementById(div2)

// for(var l=100;l>=30;l--){
//     console.log(l);
//     div2.innerHTML += ` ${l} ,`
// }

// var hh= document.getElementById(h)

// for(var m=20;m<=100;m++){
//     if(m%2==0){
//         console.log(m)

//         h.innerHTML +=`${m} <br>`
        
//     }
// }

// var pp= document.getElementById(p1)

// for(var n=900;n>=100;n--){
//     if(n%4==0){
//         console.log(n);

//         p1.innerHTML += `${n} `
//     }
// }

// var arr = document.getElementById(sec)
// var storage=["Ankita","Anki","Anku","Chiu"]

// for(var o=0;o<=storage.length;o++){
//     console.log(storage[o]);

//     sec.innerHTML=`${storage }`
// }


// // var sum=0
// //  for (var p=1;p<=50;p++){
// //     sum=sum+p
// //  }

// //  console.log(sum);

//  var sumeven=0
//  for (var p=1;p<=50;p++){
//     if(p%2==0){
//         sumeven=sumeven+p

//     }
//  }

//  console.log(sumeven);


//  var sumeve2=0
//  for (var q=300;q<=600;q++){
//     if(q%2==0){
//         sumeve2=sumeve2+q

//     }
//  }

//  console.log(sumeve2);

//  var odd=0
//  for (var r=1;r<=5;r++){
//     if(r%2!==0){
//         odd=odd+q

//     }
//  }

//  console.log(odd);


//  var su=[1,2,3,4,5,6]
// sum1=0
//  for(var s=0;s<=su.length;s++){
//     sum1 +=su[s]
//  }

//  console.log(sum1);


//  var ar=document.getElementById(at)

//  var al=[10,20,30,40,50]
//  var atotal=0
//  for(var aa=0;aa<=al.length;aa++){
//     atotal += al[aa]
//  }
//  console.log(atotal);
//  at.innerHTML=(`${atotal}`)


var a = document.getElementById("ArrT")
 sum=0

 var al=[10,20,30,40,50]
  for(var i=0;i<=al.length;i++){
     sum += al[i]
  }
  console.log(sum);
  ArrT.innerHTML=(`${sum}`)