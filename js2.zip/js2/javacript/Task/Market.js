var fc=document.getElementById("fru")
var cc=document.getElementById("fr")
no=0


function add(){

    no +=3
    fc.innerHTML=no
}

function fruit(){

    cc.innerHTML +=`${no}-`
    no=0
    fc.innerHTML=0
}


var cho=document.getElementById("cho")
var ch=document.getElementById("ch")
no=0


function add1(){

    no +=2
    cho.innerHTML=no
}

function choco(){

    ch.innerHTML +=`${no}-`
    no=0
    cho.innerHTML=0
}