var number =document.getElementById("number")
var result=document.getElementById("result")

function jp(){

    var ra=Math.floor(Math.random()*10+1)
    number.innerHTML=ra
    result.innerHTML=''

    if(ra==7){
        result.innerHTML= 'you won the jackpot'
    }
    else{
        result.innerHTML='Better luck next time'
    }

}