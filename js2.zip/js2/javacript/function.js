var finput=document.querySelector("#first")
var sinput=document.querySelector("#second")
var output=document.querySelector("#output")

console.log(finput,sinput);

function ad(){
    var add =parseInt(finput.value)+parseInt(sinput.value)

    output.innerHTML+=`Add is : ${add}<br>`

}
function sub(){
    var sub =finput.value-sinput.value

    output.innerHTML+=`sub is : ${sub}<br>`

} 
function mul(){
    var mul =finput.value*sinput.value

    output.innerHTML+=`mul is : ${mul}<br>`

}
function div(){
    var div =finput.value/sinput.value

    output.innerHTML+=`Div is : ${div}<br>`

}
function mod(){
    var mod =finput.value%sinput.value

    output.innerHTML+=`Mod is : ${mod}<br>`

}

//Hoistring

var a=20
let b=30
const c=50


demo()
// arrow()

var arrow=()=>{
    console.log("I am Arrow function");

}
function demo(){

    console.log("I am Hoisted");
}
demo()


///////////////

var f=document.querySelector("#f")
var s=document.querySelector("#s")
var t=document.querySelector("#t")
var tt=document.querySelector("#tt")

console.log(f,s,t,tt);



function addi(){

    var total=parseInt(f.value)+parseInt(s.value)+parseInt(t.value)
    tt.innerHTML=`Total is : ${total}`
}