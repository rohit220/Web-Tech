var a=123
var b=832
var c=348
var d=123

console.log(a<b);
console.log(a>b);
console.log(a<c);
console.log(a==b);
console.log(a===d);
console.log(c<=d);
console.log(a<=d);
console.log(d<a);

console.log(a!=d);
console.log(b!=c);
console.log(d!=b);


var num=100

    num+=12
    console.log(num);

    var num=234
    num-=11
    console.log(num);

    var num=766
    num*=10
    console.log(num);

    var num=877
    num/=5
    console.log(num);

    var num=231
    num%=23
    console.log(num);
 
    //Relational Operators

    console.log(true&&true);
    console.log(true&&false);
    console.log(false&&false);
    console.log(false&&true);
    
    console.log(true||false);
    console.log(false||false);
    console.log(false||true);

    console.log(!true);
    console.log(!false);
        


    // " `` "
console.log(`Hello hiii heyyyy
bye bye bye 
ok ok ok
yes 
oh!!!!`);

    var def="is a programming language"
    var def2="use for object oriented programming"

    console.log(`Java ${def} also ${def2}`);

