
var mname=["AlaVaikunthapurramuloo","Arabic Kuthu","oo Antava Mawa..Oo Oo Antava","Ra Ra Reddy"]

var imagestorage=["./media/a1.jpg","./media/a2.jpg","./media/a3.jpg","./media/a4.jpg"]

var musicsrorage=["./media/m1.mp3","./media/m2.mp3","./media/m3.mp3","./media/m4.mp3"]

var mimage=document.getElementById("mimage")
var music=document.getElementById("music")
var na=document.getElementById("na")

function player(){

    var random = Math.floor(Math.random()*imagestorage.length)
    mimage.src=imagestorage[random]
    music.src=musicsrorage[random]
    na.innerHTML=mname[random]
}